import { definePluginSettings } from "@api/Settings";
import definePlugin, { OptionType } from "@utils/types";
import { findByPropsLazy } from "@webpack";
import { React, RestAPI, Toasts } from "@webpack/common";

const Auth = findByPropsLazy("getToken");

const settings = definePluginSettings({
    deleteAllFriendsButton: {
        type: OptionType.COMPONENT,
        component: () => {
            const [isProcessing, setIsProcessing] = React.useState(false);
            const [progress, setProgress] = React.useState({ current: 0, total: 0 });

            const handleDeleteAllFriends = React.useCallback(async () => {
                setIsProcessing(true);
                setProgress({ current: 0, total: 0 });

                try {
                    const relationshipsResponse = await RestAPI.get({
                        url: "/users/@me/relationships"
                    });

                    let friends: any[] = [];

                    if (relationshipsResponse && Array.isArray(relationshipsResponse)) {
                        friends = relationshipsResponse.filter((rel: any) => rel.type === 1);
                    } else if (relationshipsResponse?.body && Array.isArray(relationshipsResponse.body)) {
                        friends = relationshipsResponse.body.filter((rel: any) => rel.type === 1);
                    }

                    if (friends.length === 0) {
                        try {
                            const channelsResponse = await RestAPI.get({
                                url: "/users/@me/channels"
                            });

                            const channels = Array.isArray(channelsResponse) 
                                ? channelsResponse 
                                : (channelsResponse?.body || []);

                            const seenIds = new Set<string>();

                            for (const channel of channels) {
                                if (channel.type === 1) {
                                    const recipients = channel.recipients || [];
                                    for (const recipient of recipients) {
                                        if (recipient.id && !seenIds.has(recipient.id)) {
                                            friends.push({
                                                user: recipient,
                                                type: 1
                                            });
                                            seenIds.add(recipient.id);
                                        }
                                    }
                                }
                            }
                        } catch (error) {
                            console.error("[DeleteFriend] Error finding friends from DMs:", error);
                        }
                    }

                    if (friends.length === 0) {
                        Toasts.show({
                            message: "No friends found.",
                            id: Toasts.genId(),
                            type: Toasts.Type.MESSAGE
                        });
                        setIsProcessing(false);
                        return;
                    }

                    // Show initial friend count
                    Toasts.show({
                        message: `Found ${friends.length} friend(s). Starting removal...`,
                        id: Toasts.genId(),
                        type: Toasts.Type.MESSAGE
                    });

                    setProgress({ current: 0, total: friends.length });

                    let successCount = 0;
                    let failCount = 0;

                    const batchSize = 5;
                    for (let i = 0; i < friends.length; i += batchSize) {
                        const batch = friends.slice(i, i + batchSize);

                        const batchPromises = batch.map(async (friend: any) => {
                            try {
                                const userId = friend.user?.id || friend.id;
                                if (!userId) return { success: false };

                                const token = Auth.getToken();

                                const response = await fetch(`https://discord.com/api/v9/users/@me/relationships/${userId}`, {
                                    method: "DELETE",
                                    headers: {
                                        "Authorization": token || "",
                                        "Content-Type": "application/json"
                                    }
                                });

                                if (response.ok || response.status === 204) {
                                    successCount++;
                                    setProgress({ current: successCount + failCount, total: friends.length });
                                    return { success: true };
                                } else {
                                    throw new Error(`HTTP ${response.status}`);
                                }
                            } catch (error: any) {
                                failCount++;
                                setProgress({ current: successCount + failCount, total: friends.length });
                                console.error("[DeleteFriend] Error removing friend:", error);
                                return { success: false };
                            }
                        });

                        await Promise.all(batchPromises);

                        if (i + batchSize < friends.length) {
                            await new Promise(resolve => setTimeout(resolve, 1000));
                        }
                    }

                    if (successCount > 0) {
                        Toasts.show({
                            message: `Successfully removed ${successCount}/${friends.length} friends.`,
                            id: Toasts.genId(),
                            type: Toasts.Type.SUCCESS
                        });
                    } else {
                        Toasts.show({
                            message: "Failed to remove friends.",
                            id: Toasts.genId(),
                            type: Toasts.Type.FAILURE
                        });
                    }

                } catch (error: any) {
                    console.error("[DeleteFriend] Error:", error);
                    Toasts.show({
                        message: `Error: ${error?.message || "Unknown error"}`,
                        id: Toasts.genId(),
                        type: Toasts.Type.FAILURE
                    });
                } finally {
                    setIsProcessing(false);
                    setProgress({ current: 0, total: 0 });
                }
            }, []);

            return (
                <div style={{ marginTop: "10px" }}>
                    <button
                        onClick={handleDeleteAllFriends}
                        disabled={isProcessing}
                        style={{
                            padding: "10px 20px",
                            backgroundColor: isProcessing ? "#4f545c" : "#f04747",
                            color: "white",
                            border: "none",
                            borderRadius: "4px",
                            cursor: isProcessing ? "not-allowed" : "pointer",
                            fontSize: "14px",
                            fontWeight: "500",
                            width: "100%",
                            transition: "all 0.2s ease"
                        }}
                    >
                        {isProcessing 
                            ? (progress.total > 0 
                                ? `Processing... (${progress.current}/${progress.total})` 
                                : "Processing...")
                            : "Remove All Friends"}
                    </button>
                    <p style={{ marginTop: "8px", fontSize: "12px", opacity: 0.7 }}>
                        This action cannot be undone! All your friends will be removed.
                    </p>
                </div>
            );
        }
    }
});

export default definePlugin({
    name: "dre-DeleteFriend",
    description: "Allows you to remove all your friends",
    authors: [{ name: "drecannn", id: 327922855276707843n }],
    settings,
});