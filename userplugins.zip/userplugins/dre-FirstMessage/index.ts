import { ApplicationCommandInputType, sendBotMessage } from "@api/Commands";
import { Logger } from "@utils/Logger";
import definePlugin from "@utils/types";
import { ChannelStore, MessageStore, NavigationRouter, SelectedChannelStore, SelectedGuildStore, FluxDispatcher } from "@webpack/common";

const logger = new Logger("FirstMessage");

function fetchMoreMessages(channelId: string): Promise<void> {
    return new Promise((resolve) => {
        const messages = MessageStore.getMessages(channelId);
        if (!messages) {
            logger.warn(`No messages object found in channel ${channelId}`);
            resolve();
            return;
        }

        let messageArray: any[] = [];
        
        // Handle different message store formats
        if (typeof messages.toArray === "function") {
            messageArray = messages.toArray();
        } else if (Array.isArray(messages)) {
            messageArray = messages;
        } else if (typeof messages === "object") {
            if (typeof messages.values === "function") {
                messageArray = Array.from(messages.values());
            } else {
                messageArray = Object.values(messages);
            }
        }

        if (messageArray.length === 0) {
            logger.warn(`No messages to fetch from in channel ${channelId}`);
            resolve();
            return;
        }
        
        const oldestMessage: any = messageArray.reduce((oldest: any, current: any) => 
            current.timestamp < oldest.timestamp ? current : oldest
        );
        
        logger.info(`Fetching messages before ${oldestMessage.id} in channel ${channelId}`);
        
        // Dispatch action to fetch more messages before the oldest one
        FluxDispatcher.dispatch({
            type: "MESSAGE_FETCH",
            channelId: channelId,
            before: oldestMessage.id,
            limit: 100
        });
        
        // Wait a bit for the fetch to complete
        setTimeout(resolve, 1000);
    });
}

async function getFirstMessage(channelId: string): Promise<any> {
    try {
        logger.info(`Getting first message for channel: ${channelId}`);
        
        let messages = MessageStore.getMessages(channelId);
        if (!messages) {
            logger.error("No messages object found in MessageStore");
            return null;
        }

        logger.info(`Initial messages count: ${messages.size || messages.length}`);

        let messageArray: any[] = [];
        
        if (typeof messages.toArray === "function") {
            messageArray = messages.toArray();
        } else if (Array.isArray(messages)) {
            messageArray = messages;
        } else if (typeof messages === "object") {
            if (typeof messages.values === "function") {
                messageArray = Array.from(messages.values());
            } else {
                messageArray = Object.values(messages);
            }
        }

        if (messageArray.length === 0) {
            logger.error("Message array is empty after conversion");
            return null;
        }
        
        // Try to fetch more messages up to 3 times to get the actual first message
        for (let i = 0; i < 3; i++) {
            logger.info(`Fetching more messages, attempt ${i + 1}/3`);
            await fetchMoreMessages(channelId);
            
            // Refresh messages after fetch
            messages = MessageStore.getMessages(channelId);
            if (messages) {
                if (typeof messages.toArray === "function") {
                    messageArray = messages.toArray();
                } else if (Array.isArray(messages)) {
                    messageArray = messages;
                } else if (typeof messages === "object") {
                    if (typeof messages.values === "function") {
                        messageArray = Array.from(messages.values());
                    } else {
                        messageArray = Object.values(messages);
                    }
                }
                logger.info(`Messages count after fetch ${i + 1}: ${messageArray.length}`);
            }
        }
        
        if (messageArray.length === 0) {
            logger.error("No messages found after all fetch attempts");
            return null;
        }
        
        // Sort by timestamp to find the earliest message
        messageArray.sort((a, b) => a.timestamp - b.timestamp);
        
        const firstMessage = messageArray[0];
        logger.info(`Found first message with ID: ${firstMessage.id}, timestamp: ${new Date(firstMessage.timestamp).toISOString()}`);
        
        return firstMessage;
    } catch (error) {
        logger.error("Error getting first message:", error);
        return null;
    }
}

function navigateToMessage(channelId: string, messageId: string): void {
    NavigationRouter.transitionTo(`/channels/${SelectedGuildStore.getGuildId() || '@me'}/${channelId}/${messageId}`);
}

export default definePlugin({
    name: "dre-FirstMessage",
    description: "Navigate to the first message in a DM channel using /firstmessage command",
    authors: [{ name: "drecannn", id: 327922855276707843n }],

    commands: [
        {
            name: "firstmessage",
            description: "Navigate to the first message in the current DM channel",
            inputType: ApplicationCommandInputType.BUILT_IN,
            execute: async (_, ctx) => {
                const channelId = ctx.channel.id;
                
                const channel = ChannelStore.getChannel(channelId);
                if (!channel) {
                    sendBotMessage(channelId, {
                        content: "Could not find channel information."
                    });
                    return;
                }

                if (channel.type !== 1 && channel.type !== 3) {
                    sendBotMessage(channelId, {
                        content: "This command only works in DM channels (direct messages or group DMs)."
                    });
                    return;
                }

                const firstMessage = await getFirstMessage(channelId);
                
                if (!firstMessage) {
                    sendBotMessage(channelId, {
                        content: "No messages found in this channel."
                    });
                    return;
                }

                navigateToMessage(channelId, firstMessage.id);
            }
        }
    ],

    start() {
        logger.info("Plugin started");
    },

    stop() {
        logger.info("Plugin stopped");
    }
});