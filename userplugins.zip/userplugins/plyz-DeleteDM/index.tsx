import { ApplicationCommandInputType, ApplicationCommandOptionType, sendBotMessage } from "@api/Commands";
import { Devs } from "@utils/constants";
import definePlugin from "@utils/types";
import { findByPropsLazy } from "@webpack";
import { RestAPI, UserStore } from "@webpack/common";

const MessageActions = findByPropsLazy("deleteMessage", "editMessage");
const FluxDispatcher = findByPropsLazy("dispatch", "subscribe");

export default definePlugin({
    name: "plyz-deletedm",
    description: "delete dm messages",
    authors: [{ name: "plyz3", id: 1395067607459172373n }],
    
    commands: [{
        name: "sil",
        description: "belirtilen kullanıcıyla olan dm deki kendi mesajlarınızı siler",
        inputType: ApplicationCommandInputType.BUILT_IN,
        options: [
            {
                name: "id",
                description: "kullanıcının ID'si",
                type: ApplicationCommandOptionType.STRING,
                required: true
            },
            {
                name: "count",
                description: "silinecek mesaj sayısı",
                type: ApplicationCommandOptionType.INTEGER,
                required: false
            }
        ],
        execute: async (args, ctx) => {
            const userId = args.find(arg => arg.name === "id")?.value as string;
            const countArg = args.find(arg => arg.name === "count")?.value;
            const count = typeof countArg === "number" ? countArg : 10;
            
            if (!userId) {
                sendBotMessage(ctx.channel.id, {
                    content: "hata"
                });
                return;
            }
            
            if (count <= 0 || count > 100) {
                sendBotMessage(ctx.channel.id, {
                    content: "hata"
                });
                return;
            }
            
            try {
                const currentUserId = UserStore.getCurrentUser()?.id;
                if (!currentUserId) {
                    sendBotMessage(ctx.channel.id, {
                        content: "hata"
                    });
                    return;
                }
                
                const dmResponse = await RestAPI.post({
                    url: "/users/@me/channels",
                    body: {
                        recipient_id: userId
                    }
                });
                
                if (!dmResponse.ok || !dmResponse.body?.id) {
                    sendBotMessage(ctx.channel.id, {
                        content: "hata"
                    });
                    return;
                }
                
                const channelId = dmResponse.body.id;
                
                let allMessages: any[] = [];
                let lastMessageId: string | null = null;
                
                for (let i = 0; i < 10; i++) {
                    const params: any = { limit: 100 };
                    if (lastMessageId) {
                        params.before = lastMessageId;
                    }
                    
                    const messagesResponse = await RestAPI.get({
                        url: `/channels/${channelId}/messages`,
                        params
                    });
                    
                    if (!messagesResponse.ok || !messagesResponse.body) {
                        break;
                    }
                    
                    const messages = messagesResponse.body;
                    if (messages.length === 0) break;
                    
                    allMessages.push(...messages);
                    lastMessageId = messages[messages.length - 1].id;
                    
                    const threeYearsAgo = Date.now() - (3 * 365 * 24 * 60 * 60 * 1000);
                    const oldestMessageTimestamp = parseInt(messages[messages.length - 1].id) >> 22;
                    
                    if (oldestMessageTimestamp < threeYearsAgo) {
                        console.log(`[plyz-DeleteDM] 3 yıldan eski mesajlara ulaşıldı, çekme durduruldu`);
                        break;
                    }
                }
                
                const myMessages = allMessages.filter((msg: any) => 
                    msg.author?.id === currentUserId
                );
                
                if (myMessages.length === 0) {
                    sendBotMessage(ctx.channel.id, {
                        content: "mesaj yok."
                    });
                    return;
                }
                
                const messagesToDelete = myMessages.slice(0, count);
                let deletedCount = 0;
                let failedCount = 0;
                
                for (const message of messagesToDelete) {
                    try {
                        await MessageActions.deleteMessage(channelId, message.id);
                        
                        FluxDispatcher.dispatch({
                            type: "MESSAGE_DELETE",
                            channelId: channelId,
                            id: message.id,
                            mlDeleted: true
                        });
                        
                        deletedCount++;
                        console.log(`[plyz-DeleteDM] Mesaj silindi: ${message.id}`);
                        
                        await new Promise(r => setTimeout(r, 100));
                        
                    } catch (error) {
                        failedCount++;
                        console.error(`[plyz-DeleteDM] Mesaj silinemedi: ${message.id}`, error);
                    }
                }
                
                sendBotMessage(ctx.channel.id, {
                    content: `tamamlandı.`
                });
                
            } catch (error) {
                console.error("[plyz-DeleteDM] Hata:", error);
                sendBotMessage(ctx.channel.id, {
                    content: "hata"
                });
            }
        }
    },
    {
        name: "ratclear",
        description: "tüm dm lerdeki ilk 4 mesajı siler",
        inputType: ApplicationCommandInputType.BUILT_IN,
        execute: async (args, ctx) => {
            try {
                const currentUserId = UserStore.getCurrentUser()?.id;
                if (!currentUserId) {
                    sendBotMessage(ctx.channel.id, {
                        content: "hata"
                    });
                    return;
                }
                
                const dmResponse = await RestAPI.get({
                    url: "/users/@me/channels"
                });
                
                if (!dmResponse.ok || !dmResponse.body) {
                    sendBotMessage(ctx.channel.id, {
                        content: "hata"
                    });
                    return;
                }
                
                const dmChannels = dmResponse.body.filter((channel: any) => channel.type === 1);
                let totalDeleted = 0;
                let totalFailed = 0;
                
                for (const channel of dmChannels) {
                    try {
                        const channelId = channel.id;
                        
                        let allMessages: any[] = [];
                        let lastMessageId: string | null = null;
                        
                        for (let i = 0; i < 10; i++) {
                            const params: any = { limit: 100 };
                            if (lastMessageId) {
                                params.before = lastMessageId;
                            }
                            
                            const messagesResponse = await RestAPI.get({
                                url: `/channels/${channelId}/messages`,
                                params
                            });
                            
                            if (!messagesResponse.ok || !messagesResponse.body) {
                                break;
                            }
                            
                            const messages = messagesResponse.body;
                            if (messages.length === 0) break;
                            
                            allMessages.push(...messages);
                            lastMessageId = messages[messages.length - 1].id;
                            
                            const threeYearsAgo = Date.now() - (3 * 365 * 24 * 60 * 60 * 1000);
                            const oldestMessageTimestamp = parseInt(messages[messages.length - 1].id) >> 22;
                            
                            if (oldestMessageTimestamp < oneWeekAgo) {
                                console.log(`[plyz-DeleteDM] 1 haftadan eski mesajlara ulaşıldı, çekme durduruldu`);
                                break;
                            }
                        }
                        
                        const myMessages = allMessages.filter((msg: any) => 
                            msg.author?.id === currentUserId
                        );
                        
                        if (myMessages.length === 0) {
                            continue;
                        }
                        
                        const messagesToDelete = myMessages.slice(0, 4);
                        
                        for (const message of messagesToDelete) {
                            try {
                                await MessageActions.deleteMessage(channelId, message.id);
                                
                                FluxDispatcher.dispatch({
                                    type: "MESSAGE_DELETE",
                                    channelId: channelId,
                                    id: message.id,
                                    mlDeleted: true
                                });
                                
                                totalDeleted++;
                                console.log(`[plyz-DeleteDM] Mesaj silindi: ${message.id} (Kanal: ${channelId})`);
                                
                                await new Promise(r => setTimeout(r, 100));
                                
                            } catch (error) {
                                totalFailed++;
                                console.error(`[plyz-DeleteDM] Mesaj silinemedi: ${message.id}`, error);
                            }
                        }
                        
                    } catch (error) {
                        totalFailed++;
                        console.error(`[plyz-DeleteDM] Kanal işlenemedi: ${channel.id}`, error);
                    }
                }
                
                sendBotMessage(ctx.channel.id, {
                    content: `tamamlandı. silinen: ${totalDeleted}`
                });
                
            } catch (error) {
                console.error("[plyz-DeleteDM] Ratclear Hata:", error);
                sendBotMessage(ctx.channel.id, {
                    content: "hata"
                });
            }
        }
    }]
});