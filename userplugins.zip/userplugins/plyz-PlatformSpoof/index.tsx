/*
 * Vencord, a Discord client mod
 * Copyright (c) 2023 Vendicated and contributors
 * SPDX-License-Identifier: GPL-3.0-or-later
 */
import { definePluginSettings } from "@api/Settings";
import definePlugin, { OptionType } from "@utils/types";
import { UserStore } from "@webpack/common";

const platformOptions = [
    { label: "Desktop",     value: "desktop",     default: true },
    { label: "Web",         value: "web"          },
    { label: "Android",     value: "android"      },
    { label: "iOS",         value: "ios"          },
    { label: "Xbox",        value: "xbox"         },
    { label: "Playstation", value: "playstation"  },
    { label: "VR",          value: "vr"           },
];

function getReleaseChannel(): string {
    try {
        // @ts-ignore
        return window.GLOBAL_ENV?.RELEASE_CHANNEL ?? "stable";
    } catch {
        return "stable";
    }
}

const settings = definePluginSettings({
    platformStable: {
        type: OptionType.SELECT,
        description: "Platform for Discord Stable",
        restartNeeded: true,
        options: platformOptions,
    },
    platformCanary: {
        type: OptionType.SELECT,
        description: "Platform for Discord Canary",
        restartNeeded: true,
        options: platformOptions,
    },
    platformPTB: {
        type: OptionType.SELECT,
        description: "Platform for Discord PTB",
        restartNeeded: true,
        options: platformOptions,
    },
});

function resolvePlatform(): string {
    const channel = getReleaseChannel();
    switch (channel) {
        case "canary": return settings.store.platformCanary ?? "desktop";
        case "ptb":    return settings.store.platformPTB    ?? "desktop";
        default:       return settings.store.platformStable ?? "desktop";
    }
}

export default definePlugin({
    name: "plyz-PlatformSpoof",
    description: "Spoof what platform or device you're on (per release channel: Stable / Canary / PTB)",
    authors: [{ name: "plyz3", id: 1395067607459172373n }],
    settings,
    patches: [
        {
            find: "_doIdentify(){",
            replacement: [
                {
                    match: /window._ws=null,null!=\i/,
                    replace: "false"
                },
                {
                    match: /(?<="GatewaySocket"\)\}\),properties:)(\i)/,
                    replace: "{...$1,...$self.getPlatform(true)}"
                },
            ]
        },
    ],
    getPlatform(bypass: boolean, userId?: string) {
        const platform = resolvePlatform();
        if (bypass || userId === UserStore.getCurrentUser().id) {
            switch (platform) {
                case "desktop":    return { browser: "Discord Client"   };
                case "web":        return { browser: "Discord Web"      };
                case "ios":        return { browser: "Discord iOS"      };
                case "android":    return { browser: "Discord Android"  };
                case "xbox":       return { browser: "Discord Embedded" };
                case "playstation":return { browser: "Discord Embedded" };
                case "vr":         return { browser: "Discord VR"       };
                default:           return null;
            }
        }
        return null;
    }
});