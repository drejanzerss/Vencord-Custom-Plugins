/*
 * Vencord, a Discord client mod
 * Copyright (c) 2026 Vendicated and contributors
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

import { ApplicationCommandInputType, ApplicationCommandOptionType, sendBotMessage } from "@api/Commands";
import ErrorBoundary from "@components/ErrorBoundary";
import { closeModal, ModalCloseButton, ModalContent, ModalHeader, ModalRoot, ModalSize, openModal } from "@utils/modal";
import definePlugin from "@utils/types";
import type { Channel, Message } from "@vencord/discord-types";
import { Button, ChannelRouter, ChannelStore, Forms, MessageStore, RestAPI, Text, Toasts, UserStore } from "@webpack/common";

const MAX_HITS = 200;
const API_REQUEST_DELAY_MS = 110;
/** Hard stop if pagination misbehaves (100 msgs per page → up to 10M msgs per DM). */
const API_PAGE_SAFETY_CAP = 100_000;

interface SearchHit {
    channelId: string;
    channelLabel: string;
    messageId: string;
    content: string;
    authorName: string;
}

function getChannelLabel(ch: Channel): string {
    try {
        if (ch.name?.trim()) return ch.name.trim();
        if (ch.isGroupDM?.()) {
            const names = ch.recipients
                ?.map(id => UserStore.getUser(id)?.username)
                .filter(Boolean) as string[] | undefined;
            if (names?.length) return names.join(", ");
            return "Group DM";
        }
        const other = ch.recipients?.[0];
        if (other) return UserStore.getUser(other)?.username ?? `User ${other}`;
    } catch { /* noop */ }
    return "DM";
}

function messageMatches(content: string | undefined, needle: string): boolean {
    if (!content) return false;
    return content.toLowerCase().includes(needle.toLowerCase());
}

function snippet(text: string, max = 160): string {
    const t = text.replace(/\s+/g, " ").trim();
    if (t.length <= max) return t;
    return `${t.slice(0, max - 1)}…`;
}

function collectFromCache(channels: Channel[], needle: string, seen: Set<string>, out: SearchHit[]): void {
    for (const ch of channels) {
        const bucket = MessageStore.getMessages(ch.id);
        const list = bucket?._array ?? [];
        const label = getChannelLabel(ch);
        for (const msg of list) {
            if (!messageMatches(msg.content, needle)) continue;
            const key = `${ch.id}:${msg.id}`;
            if (seen.has(key)) continue;
            seen.add(key);
            out.push({
                channelId: ch.id,
                channelLabel: label,
                messageId: msg.id,
                content: msg.content ?? "",
                authorName: UserStore.getUser(msg.author.id)?.username ?? msg.author.username ?? "?"
            });
            if (out.length >= MAX_HITS) return;
        }
    }
}

async function collectFromApi(
    channels: Channel[],
    needle: string,
    seen: Set<string>,
    out: SearchHit[]
): Promise<void> {
    for (const ch of channels) {
        if (out.length >= MAX_HITS) return;

        let before: string | undefined;
        for (let page = 0; page < API_PAGE_SAFETY_CAP; page++) {
            if (out.length >= MAX_HITS) return;

            const res = await RestAPI.get({
                url: `/channels/${ch.id}/messages`,
                query: {
                    limit: 100,
                    ...(before ? { before } : {})
                }
            });

            if (!res.ok || !Array.isArray(res.body) || res.body.length === 0) break;

            const label = getChannelLabel(ch);
            for (const msg of res.body as Message[]) {
                if (!messageMatches(msg.content, needle)) continue;
                const key = `${ch.id}:${msg.id}`;
                if (seen.has(key)) continue;
                seen.add(key);
                out.push({
                    channelId: ch.id,
                    channelLabel: label,
                    messageId: msg.id,
                    content: msg.content ?? "",
                    authorName: UserStore.getUser(msg.author.id)?.username ?? msg.author.username ?? "?"
                });
                if (out.length >= MAX_HITS) return;
            }

            before = (res.body as Message[])[res.body.length - 1].id;
            if (res.body.length < 100) break;
            await new Promise<void>(r => setTimeout(r, API_REQUEST_DELAY_MS));
        }
    }
}

function getDmChannels(): Channel[] {
    return ChannelStore.getSortedPrivateChannels().filter(
        ch => ChannelStore.hasChannel(ch.id) && ch.isPrivate?.() && !ch.isThread?.()
    );
}

async function runSearch(query: string, quick: boolean): Promise<SearchHit[]> {
    const needle = query.trim();
    const channels = getDmChannels();
    const seen = new Set<string>();
    const out: SearchHit[] = [];

    collectFromCache(channels, needle, seen, out);

    if (!quick && out.length < MAX_HITS)
        await collectFromApi(channels, needle, seen, out);

    return out;
}

function openResultsModal(query: string, hits: SearchHit[]): void {
    const modalKey = openModal(props => (
        <ErrorBoundary>
            <ModalRoot {...props} size={ModalSize.LARGE}>
                <ModalHeader>
                    <Text variant="heading-lg/semibold" style={{ flexGrow: 1 }}>
                        DM search: “{query}” ({hits.length} hit{hits.length === 1 ? "" : "s"})
                    </Text>
                    <ModalCloseButton onClick={() => closeModal(modalKey)} />
                </ModalHeader>
                <ModalContent>
                    {hits.length === 0 ? (
                        <Forms.FormText style={{ marginBottom: 8 }}>No matches.</Forms.FormText>
                    ) : (
                        <div
                            style={{
                                display: "flex",
                                flexDirection: "column",
                                gap: 10,
                                maxHeight: "60vh",
                                overflowY: "auto",
                                paddingBottom: 8
                            }}
                        >
                            {hits.map(h => (
                                <div
                                    key={`${h.channelId}-${h.messageId}`}
                                    style={{
                                        border: "1px solid var(--background-modifier-accent)",
                                        borderRadius: 8,
                                        padding: "10px 12px"
                                    }}
                                >
                                    <Text variant="text-md/semibold">{h.channelLabel}</Text>
                                    <Text variant="text-sm/normal" style={{ opacity: 0.85 }}>
                                        {h.authorName}
                                    </Text>
                                    <Text variant="text-sm/normal" style={{ marginTop: 6, whiteSpace: "pre-wrap" }}>
                                        {snippet(h.content)}
                                    </Text>
                                    <Button
                                        style={{ marginTop: 8 }}
                                        size="sm"
                                        onClick={() => {
                                            ChannelRouter.transitionToChannel(h.channelId);
                                            closeModal(modalKey);
                                        }}
                                    >
                                        Open channel
                                    </Button>
                                </div>
                            ))}
                        </div>
                    )}
                </ModalContent>
            </ModalRoot>
        </ErrorBoundary>
    ));
}

export default definePlugin({
    name: "plyz-DMSearch",
    description: "Search DMs: optional quick (cache only); otherwise walks each DM’s full history via API until the oldest fetchable message.",
    authors: [{ name: "plyz3", id: 1395067607459172373n }],

    commands: [
        {
            name: "dm-search",
            description: "Search all DM channels for text",
            inputType: ApplicationCommandInputType.BUILT_IN,
            options: [
                {
                    name: "query",
                    description: "Text to find (case-insensitive)",
                    type: ApplicationCommandOptionType.STRING,
                    required: true
                },
                {
                    name: "quick",
                    description: "Only messages already loaded in the client (fast; skips old history)",
                    type: ApplicationCommandOptionType.BOOLEAN,
                    required: false
                }
            ],
            execute: async (args, ctx) => {
                const rawQ = args.find(a => a.name === "query")?.value;
                const query = typeof rawQ === "string" ? rawQ.trim() : "";
                const quickRaw = args.find(a => a.name === "quick")?.value as string | boolean | undefined;
                const quick = quickRaw === true || quickRaw === "true";

                if (!query) {
                    sendBotMessage(ctx.channel.id, { content: "Provide a non-empty search query." });
                    return;
                }

                const modeLabel = quick ? "cache only" : "cache + full API history per DM";

                Toasts.show({
                    type: Toasts.Type.MESSAGE,
                    message: quick ? "Searching loaded DM messages…" : "Searching full DM history (API)…",
                    id: Toasts.genId()
                });

                try {
                    const hits = await runSearch(query, quick);
                    sendBotMessage(ctx.channel.id, {
                        content: `**plyz-DMSearch:** ${hits.length} match(es) for \`${query.replace(/`/g, "`\u200b")}\` (${modeLabel}). See modal.`
                    });
                    openResultsModal(query, hits);
                } catch (e) {
                    sendBotMessage(ctx.channel.id, {
                        content: `Search failed: ${e instanceof Error ? e.message : String(e)}`
                    });
                }
            }
        }
    ]
});
