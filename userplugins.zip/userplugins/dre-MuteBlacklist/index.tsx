import { NavContextMenuPatchCallback } from "@api/ContextMenu";
import { definePluginSettings, Settings } from "@api/Settings";
import definePlugin, { OptionType } from "@utils/types";
import type { User } from "@vencord/discord-types";
import { findByPropsLazy, findStoreLazy } from "@webpack";
import {
    ChannelStore,
    Menu,
    React,
    RestAPI,
    SelectedChannelStore,
    Toasts,
    UserStore
} from "@webpack/common";

interface VoiceState {
    userId: string;
    channelId?: string;
    oldChannelId?: string;
    deaf: boolean;
    mute: boolean;
    selfDeaf: boolean;
    selfMute: boolean;
    selfStream: boolean;
    selfVideo: boolean;
    sessionId: string;
    suppress: boolean;
    requestToSpeakTimestamp: string | null;
}

const settings = definePluginSettings({
    blacklistedUsers: {
        type: OptionType.STRING,
        description: "Blacklisted user IDs (comma-separated)",
        default: "",
        hidden: true,
    }
});

const VoiceStateStore = findStoreLazy("VoiceStateStore");

function getBlacklistedUsers(): string[] {
    const blacklistedUsersStr = Settings.plugins["dre-MuteBlacklist"].blacklistedUsers || "";
    if (!blacklistedUsersStr) return [];
    return blacklistedUsersStr.split(",").map(id => id.trim()).filter(id => id.length > 0);
}

function addToBlacklist(userId: string) {
    const current = getBlacklistedUsers();
    if (!current.includes(userId)) {
        current.push(userId);
        Settings.plugins["dre-MuteBlacklist"].blacklistedUsers = current.join(",");
        Toasts.show({
            message: "Kullanıcı mute blacklist'e eklendi",
            id: Toasts.genId(),
            type: Toasts.Type.SUCCESS
        });
    }
}

function removeFromBlacklist(userId: string) {
    const current = getBlacklistedUsers();
    const filtered = current.filter(id => id !== userId);
    Settings.plugins["dre-MuteBlacklist"].blacklistedUsers = filtered.join(",");
    Toasts.show({
        message: "Kullanıcı mute blacklist'ten çıkarıldı",
        id: Toasts.genId(),
        type: Toasts.Type.SUCCESS
    });
}

async function muteUser(guildId: string, userId: string) {
    try {
        await RestAPI.patch({
            url: `/guilds/${guildId}/members/${userId}`,
            body: {
                mute: true
            }
        });
    } catch (error: any) {
        console.error("[MuteBlacklist] Failed to mute user:", error);
    }
}

interface UserContextProps {
    user: User;
}

const UserContext: NavContextMenuPatchCallback = (children, { user }: UserContextProps) => {
    if (!user || user.id === UserStore.getCurrentUser().id) return;
    
    const blacklistedUsers = getBlacklistedUsers();
    const isBlacklisted = blacklistedUsers.includes(user.id);
    const label = isBlacklisted ? "Unblacklist Mute" : "Blacklist Mute";

    children.splice(-1, 0, (
        <Menu.MenuGroup>
            <Menu.MenuItem
                id="blacklist-mute"
                label={label}
                action={() => {
                    if (isBlacklisted) {
                        removeFromBlacklist(user.id);
                    } else {
                        addToBlacklist(user.id);
                        const myChannelId = SelectedChannelStore.getVoiceChannelId();
                        if (myChannelId) {
                            const channel = ChannelStore.getChannel(myChannelId);
                            if (channel && (channel as any).type === 2) {
                                const guildId = (channel as any).guild_id;
                                if (guildId) {
                                    const voiceStates = VoiceStateStore.getVoiceStatesForChannel(myChannelId);
                                    if (voiceStates && voiceStates[user.id]) {
                                        const userVoiceState = voiceStates[user.id];
                                        if (!userVoiceState.mute) {
                                            muteUser(guildId, user.id);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }}
            />
        </Menu.MenuGroup>
    ));
};

export default definePlugin({
    name: "dre-MuteBlacklist",
    description: "Automatically re-mutes blacklisted users when they unmute themselves",
    authors: [{ name: "drecannn", id: 327922855276707843n }],
    settings,

    contextMenus: {
        "user-context": UserContext
    },

    flux: {
        VOICE_STATE_UPDATES({ voiceStates }: { voiceStates: VoiceState[]; }) {
            const blacklistedUsers = getBlacklistedUsers();
            if (blacklistedUsers.length === 0) return;

            const myUserId = UserStore.getCurrentUser()?.id;
            if (!myUserId) return;

            const myChannelId = SelectedChannelStore.getVoiceChannelId();
            if (!myChannelId) return;

            const channel = ChannelStore.getChannel(myChannelId);
            if (!channel || (channel as any).type !== 2) return;

            const guildId = (channel as any).guild_id;
            if (!guildId) return;

            for (const { userId, mute, oldChannelId, channelId } of voiceStates) {
                if (!blacklistedUsers.includes(userId)) continue;

                const isInMyChannel = channelId === myChannelId;
                const justJoined = channelId === myChannelId && oldChannelId !== myChannelId;
                const justUnmuted = isInMyChannel && !mute;
                
                if (justUnmuted || (justJoined && !mute)) {
                    muteUser(guildId, userId);
                }
            }
        },
    },
});

