import { NavContextMenuPatchCallback } from "@api/ContextMenu";
import { definePluginSettings, Settings } from "@api/Settings";
import definePlugin, { OptionType } from "@utils/types";
import type { User } from "@vencord/discord-types";
import { findByPropsLazy, findStoreLazy } from "@webpack";
import {
    ChannelStore,
    Menu,
    React,
    RestAPI,
    SelectedChannelStore,
    Toasts,
    UserStore
} from "@webpack/common";

interface VoiceState {
    userId: string;
    channelId?: string;
    oldChannelId?: string;
    deaf: boolean;
    mute: boolean;
    selfDeaf: boolean;
    selfMute: boolean;
    selfStream: boolean;
    selfVideo: boolean;
    sessionId: string;
    suppress: boolean;
    requestToSpeakTimestamp: string | null;
}

const settings = definePluginSettings({
    blacklistedUsers: {
        type: OptionType.STRING,
        description: "Blacklisted user IDs (comma-separated)",
        default: "",
        hidden: true,
    }
});

const VoiceStateStore = findStoreLazy("VoiceStateStore");

function getBlacklistedUsers(): string[] {
    const blacklistedUsersStr = Settings.plugins["plyz-DeafenBlacklist"].blacklistedUsers || "";
    if (!blacklistedUsersStr) return [];
    return blacklistedUsersStr.split(",").map(id => id.trim()).filter(id => id.length > 0);
}

function addToBlacklist(userId: string) {
    const current = getBlacklistedUsers();
    if (!current.includes(userId)) {
        current.push(userId);
        Settings.plugins["plyz-DeafenBlacklist"].blacklistedUsers = current.join(",");
        Toasts.show({
            message: "Kullanıcı deafen blacklist'e eklendi",
            id: Toasts.genId(),
            type: Toasts.Type.SUCCESS
        });
    }
}

function removeFromBlacklist(userId: string) {
    const current = getBlacklistedUsers();
    const filtered = current.filter(id => id !== userId);
    Settings.plugins["plyz-DeafenBlacklist"].blacklistedUsers = filtered.join(",");
    Toasts.show({
        message: "Kullanıcı deafen blacklist'ten çıkarıldı",
        id: Toasts.genId(),
        type: Toasts.Type.SUCCESS
    });
}

async function deafenUser(guildId: string, userId: string) {
    try {
        await RestAPI.patch({
            url: `/guilds/${guildId}/members/${userId}`,
            body: {
                deaf: true
            }
        });
    } catch (error: any) {
        console.error("[DeafenBlacklist] Failed to deafen user:", error);
    }
}

interface UserContextProps {
    user: User;
}

const UserContext: NavContextMenuPatchCallback = (children, { user }: UserContextProps) => {
    if (!user || user.id === UserStore.getCurrentUser().id) return;
    
    const blacklistedUsers = getBlacklistedUsers();
    const isBlacklisted = blacklistedUsers.includes(user.id);
    const label = isBlacklisted ? "Unblacklist Deafen" : "Blacklist Deafen";

    children.splice(-1, 0, (
        <Menu.MenuGroup>
            <Menu.MenuItem
                id="blacklist-deafen"
                label={label}
                action={() => {
                    if (isBlacklisted) {
                        removeFromBlacklist(user.id);
                    } else {
                        addToBlacklist(user.id);
                        const myChannelId = SelectedChannelStore.getVoiceChannelId();
                        if (myChannelId) {
                            const channel = ChannelStore.getChannel(myChannelId);
                            if (channel && (channel as any).type === 2) {
                                const guildId = (channel as any).guild_id;
                                if (guildId) {
                                    const voiceStates = VoiceStateStore.getVoiceStatesForChannel(myChannelId);
                                    if (voiceStates && voiceStates[user.id]) {
                                        const userVoiceState = voiceStates[user.id];
                                        if (!userVoiceState.deaf) {
                                            deafenUser(guildId, user.id);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }}
            />
        </Menu.MenuGroup>
    ));
};

export default definePlugin({
    name: "plyz-DeafenBlacklist",
    description: "Automatically re-deafens blacklisted users when they undeafen themselves",
    authors: [{ name: "plyz3", id: 1395067607459172373n }],
    settings,

    contextMenus: {
        "user-context": UserContext
    },

    flux: {
        VOICE_STATE_UPDATES({ voiceStates }: { voiceStates: VoiceState[]; }) {
            const blacklistedUsers = getBlacklistedUsers();
            if (blacklistedUsers.length === 0) return;

            const myUserId = UserStore.getCurrentUser()?.id;
            if (!myUserId) return;

            const myChannelId = SelectedChannelStore.getVoiceChannelId();
            if (!myChannelId) return;

            const channel = ChannelStore.getChannel(myChannelId);
            if (!channel || (channel as any).type !== 2) return;

            const guildId = (channel as any).guild_id;
            if (!guildId) return;

            for (const { userId, deaf, oldChannelId, channelId } of voiceStates) {
                if (!blacklistedUsers.includes(userId)) continue;

                const isInMyChannel = channelId === myChannelId;
                const justJoined = channelId === myChannelId && oldChannelId !== myChannelId;
                const justUndeafened = isInMyChannel && !deaf;
                
                if (justUndeafened || (justJoined && !deaf)) {
                    deafenUser(guildId, userId);
                }
            }
        },
    },
});

