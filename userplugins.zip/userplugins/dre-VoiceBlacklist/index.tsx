import { NavContextMenuPatchCallback } from "@api/ContextMenu";
import { definePluginSettings, Settings } from "@api/Settings";
import definePlugin, { OptionType } from "@utils/types";
import type { User } from "@vencord/discord-types";
import { findByPropsLazy, findStoreLazy } from "@webpack";
import {
    ChannelStore,
    Menu,
    React,
    RestAPI,
    SelectedChannelStore,
    Toasts,
    UserStore
} from "@webpack/common";

interface VoiceState {
    userId: string;
    channelId?: string;
    oldChannelId?: string;
    deaf: boolean;
    mute: boolean;
    selfDeaf: boolean;
    selfMute: boolean;
    selfStream: boolean;
    selfVideo: boolean;
    sessionId: string;
    suppress: boolean;
    requestToSpeakTimestamp: string | null;
}

const settings = definePluginSettings({
    blacklistedUsers: {
        type: OptionType.STRING,
        description: "Blacklisted user IDs (comma-separated)",
        default: "",
        hidden: true,
    }
});

const VoiceStateStore = findStoreLazy("VoiceStateStore");

function getBlacklistedUsers(): string[] {
    const blacklistedUsersStr = Settings.plugins["dre-VoiceBlacklist"].blacklistedUsers || "";
    if (!blacklistedUsersStr) return [];
    return blacklistedUsersStr.split(",").map(id => id.trim()).filter(id => id.length > 0);
}

function addToBlacklist(userId: string) {
    const current = getBlacklistedUsers();
    if (!current.includes(userId)) {
        current.push(userId);
        Settings.plugins["dre-VoiceBlacklist"].blacklistedUsers = current.join(",");
        Toasts.show({
            message: "Kullanıcı blacklist'e eklendi",
            id: Toasts.genId(),
            type: Toasts.Type.SUCCESS
        });
    }
}

function removeFromBlacklist(userId: string) {
    const current = getBlacklistedUsers();
    const filtered = current.filter(id => id !== userId);
    Settings.plugins["dre-VoiceBlacklist"].blacklistedUsers = filtered.join(",");
        Toasts.show({
            message: "Kullanıcı blacklist'ten çıkarıldı",
            id: Toasts.genId(),
            type: Toasts.Type.SUCCESS
        });
}

async function disconnectUser(guildId: string, userId: string) {
    try {
        await RestAPI.patch({
            url: `/guilds/${guildId}/members/${userId}`,
            body: {
                channel_id: null
            }
        });
        
        Toasts.show({
            message: "Blacklist'teki kullanıcı sesten atıldı",
            id: Toasts.genId(),
            type: Toasts.Type.SUCCESS
        });
    } catch (error: any) {
        console.error("[VoiceBlacklist] Failed to disconnect user:", error);
        const errorMessage = error?.message || error?.toString() || "Unknown error";
        console.error("[VoiceBlacklist] Error details:", error);
        Toasts.show({
            message: `Kullanıcı atılamadı: ${errorMessage}`,
            id: Toasts.genId(),
            type: Toasts.Type.FAILURE
        });
    }
}

interface UserContextProps {
    user: User;
}

const UserContext: NavContextMenuPatchCallback = (children, { user }: UserContextProps) => {
    if (!user || user.id === UserStore.getCurrentUser().id) return;
    
    const blacklistedUsers = getBlacklistedUsers();
    const isBlacklisted = blacklistedUsers.includes(user.id);
    const label = isBlacklisted ? "Unblacklist User" : "Blacklist User";

    children.splice(-1, 0, (
        <Menu.MenuGroup>
            <Menu.MenuItem
                id="blacklist-user"
                label={label}
                action={() => {
                    if (isBlacklisted) {
                        removeFromBlacklist(user.id);
                    } else {
                        addToBlacklist(user.id);
                        const myChannelId = SelectedChannelStore.getVoiceChannelId();
                        if (myChannelId) {
                            const channel = ChannelStore.getChannel(myChannelId);
                            if (channel && (channel as any).type === 2) {
                                const guildId = (channel as any).guild_id;
                                if (guildId) {
                                    const voiceStates = VoiceStateStore.getVoiceStatesForChannel(myChannelId);
                                    if (voiceStates && voiceStates[user.id]) {
                                        disconnectUser(guildId, user.id);
                                    }
                                }
                            }
                        }
                    }
                }}
            />
        </Menu.MenuGroup>
    ));
};

export default definePlugin({
    name: "dre-VoiceBlacklist",
    description: "Automatically disconnects blacklisted users from voice channels",
    authors: [{ name: "drecannn", id: 327922855276707843n }],
    settings,

    contextMenus: {
        "user-context": UserContext
    },

    flux: {
        VOICE_STATE_UPDATES({ voiceStates }: { voiceStates: VoiceState[]; }) {
            const blacklistedUsers = getBlacklistedUsers();
            if (blacklistedUsers.length === 0) return;

            const myUserId = UserStore.getCurrentUser()?.id;
            if (!myUserId) return;

            const myChannelId = SelectedChannelStore.getVoiceChannelId();
            if (!myChannelId) return;

            const channel = ChannelStore.getChannel(myChannelId);
            if (!channel || (channel as any).type !== 2) return;

            const guildId = (channel as any).guild_id;
            if (!guildId) return;

            for (const { userId, channelId, oldChannelId } of voiceStates) {
                if (!blacklistedUsers.includes(userId)) continue;

                if (channelId === myChannelId && oldChannelId !== myChannelId) {
                    disconnectUser(guildId, userId);
                }
            }
        },
    },
});
