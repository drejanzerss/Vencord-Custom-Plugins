/*
 * Vencord, a Discord client mod
 * Copyright (c) 2024 Vendicated and contributors
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

import { definePluginSettings, Settings } from "@api/Settings";
import { Button } from "@components/Button";
import ErrorBoundary from "@components/ErrorBoundary";
import { OptionType } from "@utils/types";
import { Alerts, useState } from "@webpack/common";

import { clearLogs, Native } from ".";
import { ImageCacheDir, LogsDir } from "./components/FolderSelectInput";
import { openLogModal } from "./components/LogsModal";
import { blockedExts } from "./list";
import { DEFAULT_IMAGE_CACHE_DIR } from "./utils/constants";
import { exportLogs, importLogs } from "./utils/settingsUtils";

function ImportLogsButton() {
    const [loading, setLoading] = useState(false);

    return (
        <Button
            disabled={loading}
            onClick={async () => {
                setLoading(true);
                try {
                    await importLogs();
                } finally {
                    setLoading(false);
                }
            }}
        >
            {loading ? "Ice aktariliyor..." : "Loglari Ice Aktar"}
        </Button>
    );
}

function ExportLogsButton() {
    const [loading, setLoading] = useState(false);

    return (
        <Button
            disabled={loading}
            onClick={async () => {
                setLoading(true);
                try {
                    await exportLogs();
                } finally {
                    setLoading(false);
                }
            }}
        >
            {loading ? "Disa aktariliyor..." : "Loglari Disa Aktar"}
        </Button>
    );
}

export const settings = definePluginSettings({
    saveMessages: {
        default: true,
        type: OptionType.BOOLEAN,
        description: "Silinen ve duzenlenen mesajlar kaydedilsin.",
    },

    saveImages: {
        type: OptionType.BOOLEAN,
        description: "Silinen ekleri kaydet.",
        default: false
    },

    sortNewest: {
        default: true,
        type: OptionType.BOOLEAN,
        description: "Loglari en yeniden eskiye sirala.",
    },

    cacheMessagesFromServers: {
        default: false,
        type: OptionType.BOOLEAN,
        description: "Normalde sadece beyaz listedeki kimlikler ve DM'ler loglanir. Acarsan tum sunuculardaki mesajlar da loglanir. Bu durum onbellek limitini asip bazi mesajlarin kacmasina veya cok fazla gereksiz kayit birikmesine neden olabilir.",
    },

    ignoreBots: {
        type: OptionType.BOOLEAN,
        description: "Bot mesajlarini yok say.",
        default: false,
        onChange() {
            // we will be handling the ignoreBots now (enabled or not) so the original messageLogger shouldnt
            Settings.plugins.MessageLogger.ignoreBots = false;
        }
    },

    ignoreWebhooks: {
        type: OptionType.BOOLEAN,
        description: "Webhook mesajlarini yok say.",
        default: false,
    },

    ignoreSelf: {
        type: OptionType.BOOLEAN,
        description: "Kendi mesajlarini yok say.",
        default: false,
        onChange() {
            Settings.plugins.MessageLogger.ignoreSelf = false;
        }
    },

    ignoreMutedGuilds: {
        default: false,
        type: OptionType.BOOLEAN,
        description: "Sessize alinmis sunuculardaki mesajlar loglanmaz. Ancak beyaz listedeki kullanici/kanallar yine loglanir."
    },

    ignoreMutedCategories: {
        default: false,
        type: OptionType.BOOLEAN,
        description: "Sessize alinmis kategorilerdeki kanallarin mesajlari loglanmaz. Ancak beyaz listedekiler yine loglanir."
    },

    ignoreMutedChannels: {
        default: false,
        type: OptionType.BOOLEAN,
        description: "Sessize alinmis kanallardaki mesajlar loglanmaz. Ancak beyaz listedekiler yine loglanir."
    },

    alwaysLogDirectMessages: {
        default: true,
        type: OptionType.BOOLEAN,
        description: "DM mesajlarini her zaman logla.",
    },

    alwaysLogCurrentChannel: {
        default: true,
        type: OptionType.BOOLEAN,
        description: "Secili kanali her zaman logla. Kara listedeki kanal/kullanicilar yine yok sayilir.",
    },

    permanentlyRemoveLogByDefault: {
        default: false,
        type: OptionType.BOOLEAN,
        description: "Vencord MessageLogger'daki log silme butonu kalici olarak silsin.",
    },

    hideMessageFromMessageLoggers: {
        default: false,
        type: OptionType.BOOLEAN,
        description: "Acildiginda mesaja, diger logger'lar kaydetmeden silmeyi deneyen bir baglam menusu secenegi ekler. Risklidir, sorumluluk sende."
    },

    ShowLogsButton: {
        default: true,
        type: OptionType.BOOLEAN,
        description: "Ust bardaki log butonunu goster/gizle.",
        restartNeeded: true,
    },
    ShowKurdistanButton: {
        default: true,
        type: OptionType.BOOLEAN,
        description: "Ust bardaki Kurdistan butonunu goster/gizle.",
        restartNeeded: true,
    },

    ShowWhereMessageIsFrom: {
        default: false,
        type: OptionType.BOOLEAN,
        description: "Mesajin kanal/yazar ve sunucu bilgisini goster.",
    },

    messagesToDisplayAtOnceInLogs: {
        default: 100,
        type: OptionType.NUMBER,
        description: "Log ekraninda bir seferde gosterilecek ve 'daha fazla yukle'de eklenecek mesaj sayisi.",
    },

    hideMessageFromMessageLoggersDeletedMessage: {
        default: "redacted eh",
        type: OptionType.STRING,
        description: "'Logger'lardan gizle' ozelliginde, mesaj yerine konulacak yedek icerik.",
    },

    messageLimit: {
        default: 200,
        type: OptionType.NUMBER,
        description: "Kaydedilecek maksimum mesaj sayisi. Sinira ulasinca eski mesajlar silinir. 0 sinirsizdir."
    },

    attachmentSizeLimitInMegabytes: {
        default: 12,
        type: OptionType.NUMBER,
        description: "Kaydedilecek ekler icin MB cinsinden ust boyut limiti. Daha buyuk ekler kaydedilmez."
    },

    attachmentFileExtensions: {
        default: "png,jpg,jpeg,gif,webp,mp4,webm,mp3,ogg,wav",
        type: OptionType.STRING,
        description: "Kaydedilecek dosya uzantilari (virgulle ayir). Listede olmayan uzantilar kaydedilmez. Bos birakirsan tum ekler kaydedilir.",
        onChange: (value: string) => {
            if (!value) return;
            const exts = value.split(",").map(ext => ext.trim().toLowerCase());

            const invalid = exts.filter(ext => blockedExts.includes(ext));
            if (invalid.length > 0) {
                console.warn("Rejected invalid file extensions:", invalid);
                return exts.filter(ext => !blockedExts.includes(ext)).join(",");
            }

            return exts.join(",");
        }
    },

    cacheLimit: {
        default: 1000,
        type: OptionType.NUMBER,
        description: "Onbellekte tutulacak maksimum mesaj sayisi. Sinira ulasinca eskiler silinir. Bellek kullanimini azaltir. 0 sinirsizdir.",
    },

    timeBasedCleanupMinutes: {
        default: 0,
        type: OptionType.NUMBER,
        description: "Sunucu mesajlarini belirtilen dakikadan daha eskiyse otomatik temizle. 0 yaparsan zaman bazli temizlik kapanir.",
    },

    preserveCurrentChannel: {
        default: true,
        type: OptionType.BOOLEAN,
        description: "Acikken secili kanaldaki mesajlar zaman bazli temizlikten etkilenmez.",
    },

    whitelistedIds: {
        default: "",
        type: OptionType.STRING,
        description: "Beyaz liste sunucu/kanal/kullanici ID'leri."
    },

    blacklistedIds: {
        default: "",
        type: OptionType.STRING,
        description: "Kara liste sunucu/kanal/kullanici ID'leri."
    },

    imageCacheDir: {
        type: OptionType.COMPONENT,
        description: "Kaydedilen gorsellerin klasorunu sec",
        component: ErrorBoundary.wrap(ImageCacheDir) as any
    },

    logsDir: {
        type: OptionType.COMPONENT,
        description: "Log klasorunu sec",
        component: ErrorBoundary.wrap(LogsDir) as any
    },

    importLogs: {
        type: OptionType.COMPONENT,
        description: "Dosyadan log ice aktar",
        component: ImportLogsButton
    },

    exportLogs: {
        type: OptionType.COMPONENT,
        description: "IndexedDB loglarini disa aktar",
        component: ExportLogsButton
    },

    clearLogsOnRestart: {
        type: OptionType.BOOLEAN,
        description: "Discord yeniden baslatildiginda loglari temizle.",
        default: false,
        restartNeeded: true,
    },

    openLogs: {
        type: OptionType.COMPONENT,
        description: "Loglari ac",
        component: () =>
            <Button onClick={() => openLogModal()}>
                Loglari Ac
            </Button>
    },
    openImageCacheFolder: {
        type: OptionType.COMPONENT,
        description: "Gorsel onbellek klasorunu ac",
        component: () =>
            <Button
                disabled={
                    IS_WEB
                    || settings.store.imageCacheDir == null
                    || settings.store.imageCacheDir === DEFAULT_IMAGE_CACHE_DIR
                }
                onClick={() => Native.showItemInFolder(settings.store.imageCacheDir)}
            >
                Gorsel Onbellek Klasorunu Ac
            </Button>
    },

    clearLogs: {
        type: OptionType.COMPONENT,
        description: "Loglari temizle",
        component: () =>
            <Button
                variant="dangerPrimary"
                onClick={() => Alerts.show({
                    title: "Loglari Temizle",
                    body: "Tum loglari temizlemek istediginize emin misiniz?",
                    // @ts-expect-error not typed
                    confirmVariant: "critical-primary",
                    confirmText: "Temizle",
                    cancelText: "Iptal",
                    onConfirm: async () => {
                        await clearLogs();
                    },
                })}
            >
                Loglari Temizle
            </Button>
    },

});
