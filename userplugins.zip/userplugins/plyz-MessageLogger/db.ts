/*
 * Vencord, a Discord client mod
 * Copyright (c) 2024 Vendicated and contributors
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

import { ChannelStore, Toasts } from "@webpack/common";

import { LoggedMessageJSON } from "./types";
import { getMessageStatus } from "./utils";
import { stripTransientRenderState } from "./utils/cleanUp";
import { DB_NAME, DB_VERSION } from "./utils/constants";
import { getAttachmentBlobUrl } from "./utils/saveImage";

export enum DBMessageStatus {
    DELETED = "DELETED",
    EDITED = "EDITED",
    GHOST_PINGED = "GHOST_PINGED",
}

export interface DBMessageRecord {
    message_id: string;
    channel_id: string;
    status: DBMessageStatus;
    message: LoggedMessageJSON;
}

export let db: IDBDatabase;
export const cachedMessages = new Map<string, LoggedMessageJSON>();

function req<T>(request: IDBRequest<T>) {
    return new Promise<T>((resolve, reject) => {
        request.onsuccess = () => resolve(request.result);
        request.onerror = () => reject(request.error);
    });
}

function txDone(tx: IDBTransaction) {
    return new Promise<void>((resolve, reject) => {
        tx.oncomplete = () => resolve();
        tx.onerror = () => reject(tx.error);
        tx.onabort = () => reject(tx.error);
    });
}

// this is probably not the best way to do this
async function cacheRecords(records: DBMessageRecord[]) {
    for (const r of records) {
        cacheRecord(r);

        for (const att of r.message.attachments) {
            const blobUrl = await getAttachmentBlobUrl(att);
            if (blobUrl) {
                att.url = blobUrl + "#";
                att.proxy_url = blobUrl + "#";
            }
        }
    }
    return records;
}

async function cacheRecord(record?: DBMessageRecord | null) {
    if (!record) return record;

    stripTransientRenderState(record.message);
    cachedMessages.set(record.message_id, record.message);
    return record;
}

export async function initIDB() {
    if (db) return;
    db = await new Promise<IDBDatabase>((resolve, reject) => {
        const openReq = indexedDB.open(DB_NAME, DB_VERSION);
        openReq.onupgradeneeded = () => {
            const upDb = openReq.result;
            if (upDb.objectStoreNames.contains("messages")) return;
            const messageStore = upDb.createObjectStore("messages", { keyPath: "message_id" });
            messageStore.createIndex("by_channel_id", "channel_id");
            messageStore.createIndex("by_status", "status");
            messageStore.createIndex("by_timestamp", "message.timestamp");
            messageStore.createIndex("by_timestamp_and_message_id", ["channel_id", "message.timestamp"]);
        };
        openReq.onsuccess = () => resolve(openReq.result);
        openReq.onerror = () => reject(openReq.error);
    });
}
initIDB();

export async function hasMessageIDB(message_id: string) {
    if (cachedMessages.has(message_id)) return true;
    const tx = db.transaction("messages", "readonly");
    const store = tx.objectStore("messages");
    return (await req(store.count(message_id))) > 0;
}

export async function countMessagesIDB() {
    const tx = db.transaction("messages", "readonly");
    return req(tx.objectStore("messages").count());
}

export async function countMessagesByStatusIDB(status: DBMessageStatus) {
    const messages = await getMessagesByStatusIDB(status);
    return messages.length;
}

export async function getAllMessagesIDB() {
    const tx = db.transaction("messages", "readonly");
    return cacheRecords(await req(tx.objectStore("messages").getAll()));
}

export async function getMessagesForChannelIDB(channel_id: string) {
    const all = await getAllMessagesIDB();
    return all.filter(m => m.channel_id === channel_id);
}

export async function getMessageIDB(message_id: string) {
    const tx = db.transaction("messages", "readonly");
    return cacheRecord(await req(tx.objectStore("messages").get(message_id)));
}

export async function getMessagesByStatusIDB(status: DBMessageStatus) {
    const all = await getAllMessagesIDB();
    return all.filter(m => m.status === status);
}

export async function getOldestMessagesIDB(limit: number) {
    const all = await getAllMessagesIDB();
    return all
        .sort((a, b) => a.message.timestamp.localeCompare(b.message.timestamp))
        .slice(0, limit);
}

export async function* iterateAllMessagesIDB(batchSize = 100) {
    const all = await getAllMessagesIDB();
    for (let i = 0; i < all.length; i += batchSize) {
        const batch = all.slice(i, i + batchSize);
        if (!batch.length) break;
        yield batch;
    }
}

export async function getOlderThanTimestampIDB(timestamp: string) {
    const all = await getAllMessagesIDB();
    return all.filter(m => m.message.timestamp <= timestamp);
}

export async function getOlderThanTimestampForGuildsIDB(timestamp: string, currentChannelId?: string, preserveCurrentChannel?: boolean) {
    const allOldMessages = await getOlderThanTimestampIDB(timestamp);
    return allOldMessages.filter(record => {
        const { message } = record;
        const channel = ChannelStore.getChannel(message.channel_id);
        const isGuildMessage = channel?.guild_id != null;
        const isCurrentChannel = preserveCurrentChannel && currentChannelId && message.channel_id === currentChannelId;
        return isGuildMessage && !isCurrentChannel;
    });
}

export async function getDateStortedMessagesByStatusIDB(newest: boolean, limit: number, status: DBMessageStatus) {
    const filtered = await getMessagesByStatusIDB(status);
    const sorted = filtered.sort((a, b) =>
        newest
            ? b.message.timestamp.localeCompare(a.message.timestamp)
            : a.message.timestamp.localeCompare(b.message.timestamp)
    );
    return sorted.slice(0, limit);
}

export async function getMessagesByChannelAndAfterTimestampIDB(channel_id: string, start: string) {
    const byChannel = await getMessagesForChannelIDB(channel_id);
    return byChannel.filter(m => m.message.timestamp >= start);
}

export async function addMessageIDB(message: LoggedMessageJSON, status: DBMessageStatus) {
    stripTransientRenderState(message);

    if (!db) await initIDB();
    const tx = db.transaction("messages", "readwrite");
    tx.objectStore("messages").put({
        channel_id: message.channel_id,
        message_id: message.id,
        status,
        message,
    });
    await txDone(tx);

    cachedMessages.set(message.id, message);
}

export async function addMessagesBulkIDB(messages: LoggedMessageJSON[], status?: DBMessageStatus) {
    messages.forEach(stripTransientRenderState);

    const tx = db.transaction("messages", "readwrite");
    const store = tx.objectStore("messages");
    for (const message of messages) {
        store.put({
            channel_id: message.channel_id,
            message_id: message.id,
            status: status ?? getMessageStatus(message),
            message,
        });
    }
    await txDone(tx);

    messages.forEach(message => cachedMessages.set(message.id, message));
}

export async function deleteMessageIDB(message_id: string) {
    const tx = db.transaction("messages", "readwrite");
    tx.objectStore("messages").delete(message_id);
    await txDone(tx);

    cachedMessages.delete(message_id);
}

export async function deleteMessagesBulkIDB(message_ids: string[]) {
    const tx = db.transaction("messages", "readwrite");
    const store = tx.objectStore("messages");

    for (const id of message_ids) store.delete(id);
    await txDone(tx);
    message_ids.forEach(id => cachedMessages.delete(id));
}

export async function clearMessagesIDB(showToast = true) {
    cachedMessages.clear();
    const tx = db.transaction("messages", "readwrite");
    tx.objectStore("messages").clear();
    await txDone(tx);
    if (!showToast) return;

    Toasts.show({
        type: Toasts.Type.MESSAGE,
        message: "Cleared message log database and cache.",
        id: Toasts.genId()
    });
}
