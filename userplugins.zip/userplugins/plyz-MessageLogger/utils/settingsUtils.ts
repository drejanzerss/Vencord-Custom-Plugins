/*
 * Vencord, a modification for Discord's desktop app
 * Copyright (c) 2023 Vendicated and contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

import { chooseFile as chooseFileWeb } from "@utils/web";
import { Toasts } from "@webpack/common";

import { clearLogs,Native } from "..";
import { addMessagesBulkIDB, iterateAllMessagesIDB } from "../db";
import { LoggedMessageJSON } from "../types";

export async function importLogs() {
    try {
        let count = 0;
        const batchSize = 50;
        let batch: LoggedMessageJSON[] = [];
        let cleared = false;

        for await (const logItems of iterateLogItems()) {
            if (!cleared) {
                await clearLogs(false);
                cleared = true;
            }

            const items = logItems.flat();

            for (const item of items) {
                const { message } = item;
                if (!message || !message.id || !message.channel_id || !message.timestamp) continue;

                batch.push(message);

                if (batch.length >= batchSize) {
                    await addMessagesBulkIDB(batch);
                    count += batch.length;
                    batch = [];
                }
            }
        }

        if (batch.length > 0) {
            await addMessagesBulkIDB(batch);
            count += batch.length;
        }

        if (count === 0) {
            Toasts.show({
                id: Toasts.genId(),
                message: "No messages found in log file",
                type: Toasts.Type.FAILURE
            });
            return;
        }

        Toasts.show({
            id: Toasts.genId(),
            message: `Successfully imported ${count} logs`,
            type: Toasts.Type.SUCCESS
        });
    } catch (e) {
        console.error(e);

        Toasts.show({
            id: Toasts.genId(),
            message: "Error importing logs. Check the console for more information",
            type: Toasts.Type.FAILURE
        });
    }
}

export async function exportLogs() {
    const filename = "message-logger-logs-idb.json";

    try {
        if (!IS_WEB) {
            const streamId = await Native.startNativeLogExport(filename);

            await Native.writeNativeLogChunk(streamId, '{\n  "messages": [\n');

            let first = true;
            for await (const record of iterateAllMessagesIDB()) {
                const prefix = first ? "" : ",\n";
                first = false;

                const chunk = prefix + "    " + JSON.stringify(record);

                await Native.writeNativeLogChunk(streamId, chunk);
            }

            await Native.writeNativeLogChunk(streamId, "\n  ]\n}");
            await Native.finishNativeLogExport(streamId);

            Toasts.show({
                id: Toasts.genId(),
                message: "Successfully exported logs",
                type: Toasts.Type.SUCCESS
            });
            return;
        }

        if (IS_WEB) {
            const chunks: string[] = ['{\n  "messages": [\n'];

            let first = true;
            let count = 0;
            for await (const records of iterateAllMessagesIDB()) {
                const prefix = first ? "" : ",\n";
                first = false;
                const chunk = prefix + "    " + JSON.stringify(records);
                chunks.push(chunk);
                count++;
            }

            chunks.push("\n  ]\n}");
            const blob = new Blob([chunks.join("")], { type: "application/json" });
            const link = document.createElement("a");
            const objectUrl = URL.createObjectURL(blob);
            link.href = objectUrl;
            link.download = filename;
            link.click();
            link.remove();
            URL.revokeObjectURL(objectUrl);

            Toasts.show({
                id: Toasts.genId(),
                message: `Successfully exported ${count} logs`,
                type: Toasts.Type.SUCCESS
            });
        }
    } catch (e) {
        console.error(e);

        Toasts.show({
            id: Toasts.genId(),
            message: "Error exporting logs. Check the console for more information",
            type: Toasts.Type.FAILURE
        });
    }
}

async function* iterateLogItems(): AsyncGenerator<any> {
    if (IS_WEB) {
        const file = await chooseFileWeb(".json");
        if (!file) throw new Error("No file selected");
        const data = JSON.parse(await file.text());
        if (Array.isArray(data?.messages)) yield data.messages;
    } else {
        const settings = await Native.getSettings();
        const fileId = await Native.startNativeLogImport(settings.logsDir);

        try {
            let full = "";
            while (true) {
                const chunk = await Native.readNativeLogChunk(fileId);
                if (chunk == null) break;
                full += chunk;
            }
            const data = JSON.parse(full);
            if (Array.isArray(data?.messages)) yield data.messages;
        } finally {
            await Native.closeNativeLogImport(fileId);
        }
    }
}
