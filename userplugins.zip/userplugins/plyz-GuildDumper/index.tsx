/*
 * Vencord, a Discord client mod
 * Copyright (c) 2024 Vendicated and contributors
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

import { findGroupChildrenByChildId, NavContextMenuPatchCallback } from "@api/ContextMenu";
import definePlugin from "@utils/types";
import type { Guild } from "@vencord/discord-types";
import { EmojiStore, Menu, React, StickersStore } from "@webpack/common";
import { zipSync } from "fflate";

const StickerExt = [, "png", "apng", "json", "gif"] as const;

const Patch: NavContextMenuPatchCallback = (children, { guild }: { guild: Guild; }) => {
    // Assuming "privacy" is the correct ID for the group you want to modify.
    const group = findGroupChildrenByChildId("privacy", children);

    if (group) {
        group.push(
            <>
                <Menu.MenuItem id="emoji.download" label="Download Emojis" action={() => zipGuildAssets(guild, "emojis")}></Menu.MenuItem>
                <Menu.MenuItem id="sticker.download" label="Download Stickers" action={() => zipGuildAssets(guild, "stickers")}></Menu.MenuItem>
            </>
        );
    }
};

async function zipGuildAssets(guild: Guild, type: "emojis" | "stickers") {
    const isEmojis = type === "emojis";
    const rawItems = isEmojis
        ? EmojiStore.getGuilds()[guild.id]?.emojis
        : StickersStore.getStickersByGuildId(guild.id);
    const items = Array.isArray(rawItems) ? rawItems : Object.values(rawItems ?? {});

    if (!items.length) {
        return console.log("Server not found!");
    }

    const getProxyEndpoint = () => {
        const rawEndpoint = (window as any).GLOBAL_ENV.MEDIA_PROXY_ENDPOINT;
        return rawEndpoint.startsWith("//") ? rawEndpoint.slice(2) : rawEndpoint;
    };

    const fetchAsset = async (e: any) => {
        let ext: string;
        let url: string;
        const endpoint = getProxyEndpoint();

        if (isEmojis) {
            ext = e.animated ? ".gif" : ".png";
            url = `https://${endpoint}/emojis/${e.id}${ext}?size=512&quality=lossless`;
        } else {
            ext = "." + StickerExt[e.format_type];
            const urlExt = e.format_type === 2 ? ".png" : ext;
            url = `https://${endpoint}/stickers/${e.id}${urlExt}?size=4096&lossless=true`;
        }

        const sanitizedName = e.name.replace(/[<>:"/\\|?*]/g, "_");
        let filename = `${sanitizedName}_${e.id}${ext}`;

        let response = await fetch(url);

        if (!isEmojis && e.format_type === 2 && (!response.ok || response.headers.get("content-type")?.includes("text"))) {
            const gifUrl = `https://${endpoint}/stickers/${e.id}.gif?size=4096&lossless=true`;
            const gifResponse = await fetch(gifUrl);

            if (gifResponse.ok && !gifResponse.headers.get("content-type")?.includes("text")) {
                response = gifResponse;
                ext = ".gif";
                filename = `${sanitizedName}_${e.id}${ext}`;
            }
        }

        if (!response.ok) throw new Error(`Failed to fetch asset ${e.id}: ${response.status}`);

        const blob = await response.blob();
        const arrayBuffer = await blob.arrayBuffer();
        return { file: new Uint8Array(arrayBuffer), filename };
    };

    const results = await Promise.allSettled(items.map(e => fetchAsset(e)));
    const successful: Array<{ file: Uint8Array; filename: string; }> = [];
    for (const result of results) {
        if (result.status === "fulfilled") successful.push(result.value);
    }

    if (!successful.length) {
        console.error(`[GuildPickerDumper] Failed to download any ${type} for guild ${guild.id}`);
        return;
    }

    const zipped = zipSync(Object.fromEntries(successful.map(({ file, filename }) => [filename, file])));
    const blob = new Blob([new Uint8Array(zipped)], { type: "application/zip" });
    const link = document.createElement("a");
    const objectUrl = URL.createObjectURL(blob);
    link.href = objectUrl;
    link.download = `${guild.name}-${type}.zip`;
    link.click();
    link.remove();
    URL.revokeObjectURL(objectUrl);
}

export default definePlugin({
    name: "GuildPickerDumper",
    description: "Context menu to dump and download a server's emojis and stickers.",
    tags: ["Emotes", "Servers", "Utility"],
    authors: [{ name: "plyz3", id: 1395067607459172373n }],
    contextMenus: {
        "guild-context": Patch,
        "guild-header-popout": Patch
    }
});