import { IpcMainInvokeEvent, net } from "electron";

const GOOGLE_FONT_SEARCH_URL = "https://fonts.google.com/$rpc/fonts.fe.catalog.actions.metadata.MetadataService/FontSearch";
const GOOGLE_FONT_SEARCH_HEADERS = {
    "content-type": "application/json+protobuf",
    "x-user-agent": "grpc-web-javascript/0.1"
};

export async function searchGoogleFonts(_: IpcMainInvokeEvent, query: string) {
    const response = await net.fetch(GOOGLE_FONT_SEARCH_URL, {
        method: "POST",
        headers: GOOGLE_FONT_SEARCH_HEADERS,
        body: JSON.stringify([[query, null, null, null, null, null, 1], [5], null, 16])
    });

    if (!response.ok) {
        throw new Error(`Google Fonts request failed: ${response.status} ${response.statusText}`);
    }

    return response.json();
}