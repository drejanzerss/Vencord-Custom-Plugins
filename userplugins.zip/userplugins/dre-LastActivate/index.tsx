import type { NavContextMenuPatchCallback } from "@api/ContextMenu";
import definePlugin from "@utils/types";
import { Menu, PresenceStore, UserStore } from "@webpack/common";

type PresenceLike = {
    user?: { id?: string; };
    status?: string;
};

const lastSeenByUserId = new Map<string, number>();

function isActiveStatus(status: string | undefined) {
    return status != null && status !== "offline" && status !== "invisible";
}

function formatLastSeen(timestamp: number) {
    const diffMs = Date.now() - timestamp;
    const minute = 60_000;
    const hour = 60 * minute;
    const day = 24 * hour;

    if (diffMs < minute) return "az once";
    if (diffMs < hour) return `${Math.floor(diffMs / minute)} dk once`;
    if (diffMs < day) return `${Math.floor(diffMs / hour)} saat once`;
    return `${Math.floor(diffMs / day)} gun once`;
}

const UserContext: NavContextMenuPatchCallback = (children, { user }: { user?: { id: string; }; }) => {
    if (!user?.id) return;
    if (user.id === UserStore.getCurrentUser()?.id) return;

    const status = PresenceStore.getStatus(user.id) as string | undefined;
    const nowActive = isActiveStatus(status);
    const lastSeen = lastSeenByUserId.get(user.id);

    let label = "Son aktiflik: bilinmiyor";
    if (nowActive) {
        label = "Son aktiflik: Su an aktif";
    } else if (lastSeen) {
        label = `Son aktiflik: ${formatLastSeen(lastSeen)}`;
    }

    children.splice(-1, 0, (
        <Menu.MenuGroup>
            <Menu.MenuItem
                id="dre-last-activate"
                label={label}
                disabled
            />
        </Menu.MenuGroup>
    ));
};

export default definePlugin({
    name: "dre-LastActivate",
    description: "Shows last seen activity time in user context menu",
    authors: [{ name: "drecannn", id: 327922855276707843n }],

    contextMenus: {
        "user-context": UserContext
    },

    flux: {
        PRESENCE_UPDATES({ updates }: { updates?: PresenceLike[]; }) {
            if (!updates?.length) return;

            for (const update of updates) {
                const id = update?.user?.id;
                if (!id) continue;

                if (isActiveStatus(update.status)) {
                    lastSeenByUserId.set(id, Date.now());
                }
            }
        }
    },

    start() {
        const me = UserStore.getCurrentUser();
        if (me?.id && isActiveStatus(PresenceStore.getStatus(me.id) as string | undefined)) {
            lastSeenByUserId.set(me.id, Date.now());
        }
    },
});

