/*
 * Vencord, a Discord client mod
 * Copyright (c) 2025 Vendicated and contributors
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

import "./styles.css";

import { definePluginSettings } from "@api/Settings";
import { Margins } from "@utils/margins";
import { classes } from "@utils/misc";
import definePlugin, { OptionType } from "@utils/types";
import { React, TextInput, Forms } from "@webpack/common";

interface GoogleFontMetadata {
    family: string;
    displayName: string;
    authors: string[];
    category?: string;
    variants: Array<{
        axes: Array<{ tag: string; min: number; max: number; }>;
    }>;
}

function getNative() {
    return (VencordNative.pluginHelpers as any)["dre-FontLoader"] as PluginNative<typeof import("./native")> | undefined;
}

async function searchGoogleFonts(query: string): Promise<GoogleFontMetadata[]> {
    try {
        const payload = [[query, null, null, null, null, null, 1], [5], null, 16];
        const native = getNative();

        const data = native
            ? await native.searchGoogleFonts(query)
            : await fetch("https://fonts.google.com/$rpc/fonts.fe.catalog.actions.metadata.MetadataService/FontSearch", {
                method: "POST",
                headers: {
                    "content-type": "application/json+protobuf",
                    "x-user-agent": "grpc-web-javascript/0.1"
                },
                body: JSON.stringify(payload)
            }).then(r => r.json());

        if (!data?.[1]) return [];
        return data[1].map(([_, fontData]: [string, any[]]) => ({
            family: fontData[0],
            displayName: fontData[1],
            authors: fontData[2],
            category: fontData[3],
            variants: (fontData[6] ?? []).map((variant: any[]) => ({
                axes: (variant[0] ?? []).map(([tag, min, max]: [string, number, number]) => ({
                    tag, min, max
                }))
            }))
        }));
    } catch (err) {
        console.error("[dre-FontLoader] Failed to search fonts:", err);
        return [];
    }
}

const createGoogleFontUrl = (family: string, options = "") =>
    `https://fonts.googleapis.com/css2?family=${encodeURIComponent(family)}${options}&display=swap`;

const loadFontLink = (url: string): HTMLLinkElement => {
    const link = document.createElement("link");
    link.rel = "stylesheet";
    link.href = url;
    document.head.appendChild(link);
    return link;
};

const previewFontLinks: HTMLLinkElement[] = [];

const preloadFont = (family: string) => {
    const link = loadFontLink(
        createGoogleFontUrl(family, "&text=The%20quick%20brown%20fox%20jumps%20over%20the%20lazy%20dog")
    );
    previewFontLinks.push(link);
};

const clearPreviewFonts = () => {
    previewFontLinks.forEach(l => l.remove());
    previewFontLinks.length = 0;
};

let styleElement: HTMLStyleElement | null = null;
let appliedFontLink: HTMLLinkElement | null = null;

const applyFont = (fontFamily: string) => {
    if (!fontFamily) {
        appliedFontLink?.remove();
        appliedFontLink = null;
        styleElement?.remove();
        styleElement = null;
        return;
    }
    try {
        appliedFontLink?.remove();
        appliedFontLink = loadFontLink(createGoogleFontUrl(fontFamily, ":wght@300;400;500;600;700"));

        if (!styleElement) {
            styleElement = document.createElement("style");
            document.head.appendChild(styleElement);
        }

        const applyToCode = settings.store.applyOnCodeBlocks;
        styleElement.textContent = `
            * {
                --font-primary: '${fontFamily}', sans-serif !important;
                --font-display: '${fontFamily}', sans-serif !important;
                --font-headline: '${fontFamily}', sans-serif !important;
                ${applyToCode ? `--font-code: '${fontFamily}', monospace !important;` : ""}
            }
        `;
    } catch (err) {
        console.error("[dre-FontLoader] Failed to apply font:", err);
    }
};

function debounce<T extends (...args: any[]) => any>(fn: T, ms: number) {
    let t: ReturnType<typeof setTimeout>;
    return (...args: Parameters<T>) => { clearTimeout(t); t = setTimeout(() => fn(...args), ms); };
}

function GoogleFontSearch({ onSelect }: { onSelect: (font: GoogleFontMetadata) => void; }) {
    const [query, setQuery] = React.useState("");
    const [results, setResults] = React.useState<GoogleFontMetadata[]>([]);
    const [loading, setLoading] = React.useState(false);
    const [selected, setSelected] = React.useState(settings.store.selectedFont ?? "");

    React.useEffect(() => () => { clearPreviewFonts(); }, []);

    const doSearch = React.useMemo(() => debounce(async (value: string) => {
        if (!value.trim()) {
            clearPreviewFonts();
            setResults([]);
            setLoading(false);
            return;
        }
        const fonts = await searchGoogleFonts(value);
        clearPreviewFonts();
        fonts.forEach(f => preloadFont(f.family));
        setResults(fonts);
        setLoading(false);
    }, 350), []);

    const handleSearch = (value: string) => {
        setQuery(value);
        setLoading(!!value.trim());
        doSearch(value);
    };

    const handleSelect = (font: GoogleFontMetadata) => {
        setSelected(font.family);
        onSelect(font);
    };

    return (
        <section className="vc-fontloader-section">
            <Forms.FormTitle tag="h2" className={Margins.bottom8}>
                Search Google Fonts
            </Forms.FormTitle>
            <Forms.FormText className={Margins.bottom16}>
                Search and click any font to apply it across Discord.
            </Forms.FormText>

            <div className="vc-fontloader-input-wrap">
                <TextInput
                    value={query}
                    onChange={handleSearch}
                    placeholder="Type to search fonts… e.g. Roboto, Montserrat, Lato"
                />
            </div>

            {loading && (
                <Forms.FormText className={classes(Margins.top8, "vc-fontloader-loading")}>
                    Searching…
                </Forms.FormText>
            )}

            {!loading && results.length > 0 && (
                <div className={classes("vc-fontloader-results", Margins.top8)}>
                    {results.map(font => {
                        const isSel = font.family === selected;
                        return (
                            <div
                                key={font.family}
                                className={classes(
                                    "vc-fontloader-card",
                                    Margins.bottom8,
                                    isSel && "vc-fontloader-card--selected"
                                )}
                                onClick={() => handleSelect(font)}
                            >
                                <div
                                    className="vc-fontloader-preview"
                                    style={{ fontFamily: `'${font.family}', sans-serif` }}
                                >
                                    <Forms.FormTitle
                                        tag="h4"
                                        style={{ fontFamily: "inherit", margin: 0 }}
                                    >
                                        {font.displayName}
                                    </Forms.FormTitle>
                                    <Forms.FormText style={{ fontFamily: "inherit" }}>
                                            Chabos wissen wer der babo ist
                                    </Forms.FormText>
                                </div>

                                <Forms.FormText
                                    className={Margins.top8}
                                    style={{ opacity: 0.5, fontSize: "11px" }}
                                >
                                    by drecan
                                </Forms.FormText>

                                {isSel && (
                                    <span className="vc-fontloader-selected-badge">✓ Applied</span>
                                )}
                            </div>
                        );
                    })}
                </div>
            )}

            {!loading && query.trim() && results.length === 0 && (
                <Forms.FormText className={classes(Margins.top8, "vc-fontloader-empty")}>
                    No fonts found for "{query}". Try a different search term.
                </Forms.FormText>
            )}

        </section>
    );
}

function ResetFontButton() {
    return (
        <button
            className="vc-fontloader-reset-btn"
            onClick={() => {
                clearPreviewFonts();
                settings.store.selectedFont = "";
                applyFont("");
            }}
        >
            Reset
        </button>
    );
}

const settings = definePluginSettings({
    selectedFont: {
        type: OptionType.STRING,
        description: "Currently selected font family",
        default: "",
        hidden: true
    },
    fontSearch: {
        type: OptionType.COMPONENT,
        description: "Search and select a font from Google Fonts",
        component: () => (
            <GoogleFontSearch
                onSelect={font => {
                    settings.store.selectedFont = font.family;
                    applyFont(font.family);
                }}
            />
        )
    },
    applyOnCodeBlocks: {
        type: OptionType.BOOLEAN,
        description: "Also apply the selected font to code blocks",
        default: false
    },
    resetFont: {
        type: OptionType.COMPONENT,
        description: "",
        component: ResetFontButton
    }
});

export default definePlugin({
    name: "dre-FontLoader",
    description: "Load and apply any font from Google Fonts across Discord",
    tags: ["appearance", "font", "customization"],
    authors: [{ name: "drecannn", id: 327922855276707843n }],

    settings,

    start() {
        const saved = settings.store.selectedFont;
        if (saved) applyFont(saved);
    },

    stop() {
        appliedFontLink?.remove();
        appliedFontLink = null;
        styleElement?.remove();
        styleElement = null;
        clearPreviewFonts();
    }
});